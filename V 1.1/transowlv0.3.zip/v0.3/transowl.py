from flask import (
	Flask, request, url_for, render_template, jsonify
	)
#import os
from random import randint
from secrets import token_hex

### Init de l'app
app = Flask(__name__)

### Variables globales

codes = {"00000000": '7f14c9b91b6de141'}
newmessages = {}

### fonctions serveur uniquement

def verif(identification, code):  # rajouter un hashage pour + de sécu
	"""
	:param identification: l'id spécifique à l'utilisateur client
	:param code: le code spécifique
	:return: Vrai ou faux dépendant de si ce code correspond bien à celui de l'utilisateur
	"""
	return (codes.get(identification) == code)

def addtobuffer(content, src, to, key): #changer l'ordre bizarre des variables
	"""

	:param content: le message ou la clef
	:param src: l'id de l'utilisateur qui envoie
	:param to: l'id de l'utilisateur qui reçoit
	:param key: vrai ou faux dépendant de si c'est l'envoi de la clef ou d'un message
	:return: rien.

	"""
	if key == "true":
		newmessages[to].append({"id": src, "msg": content, "key": "true"})
	else:
		newmessages[to].append({"id": src, "msg": content, "key": "false"})
	print(newmessages)
	
def readbuffer(id_check):
	"""
	Lit les nouveaux messages et supprime ceux déjà lus.
	:param id_check: l'id de la personne pour lquelle on lit le buffer:
	:return: la liste des messages envoyées à l'utilsateur id_check

	"""
	a = newmessages[id_check]
	newmessages[id_check] = []
	return a

### Chemins d'accès

@app.route("/")
@app.route("/home")
def home():
	"""
	Appelée quand le client va sur l'adresse / ou /home
	:return: renvoie la page html principale à l'utilisateur
	"""
	return render_template("conv.html")

@app.route("/expire", methods=["GET", "POST"])
def expired():
	"""
	Appelée quand verif renvoie False
	:return: une page d'expiration, qui permet de se réconnecter à la page principale
	"""
	return render_template("expire.html")

### Traitement des requêtes ajax

@app.route("/getid", methods=["GET", "POST"])
def getid():
	"""
	Appelée quand le client charge la page
	:return: renvoie l'id spécifique du client ainsi que le code associé
	"""
	global codes

	if request.method == "POST" :
		r = 10_000_000
		# r =  randint(0, 100_000_000)
		while codes.get(str(r).zfill(8)) != None :
			r = randint(0, 100_000_000)
		code = token_hex(8)
		codes[str(r).zfill(8)] = code
		newmessages[str(r).zfill(8)] = []
	
		return jsonify({"userid":str(r).zfill(8), "usercode":code})


@app.route("/send", methods=["GET", "POST"])
def send():
	"""
	Appelée quand l'utilisateur envoie un message
	:return: la valeur renvoyée n'a pas une grande utilité,
	"""
	if request.method == "POST" :
		msgData = request.get_json()

		if verif(msgData["userid"], msgData["usercode"]):
			try :
				addtobuffer(msgData["msg"], msgData["userid"].zfill(8), msgData["to"].zfill(8), msgData["key"])
				return {}, 200

			except KeyError : return "ID d'utilisateur invalide", 400

		else : return "Session expiree", 403


@app.route("/check", methods=["GET", "POST"])  
def check():
	"""
	Appelé périodiquement par le client (toutes les secondes) pour vérifier si de nouveaux messages ont été envoyés
	:return: une liste des messages reçus depuis le dernière appel
	"""
	if request.method == "POST":
		rqData = request.get_json()

		if verif(rqData["userid"], rqData["usercode"]):
			buffed = readbuffer(rqData["userid"])
			return jsonify(buffed)

		else : return "Session expiree", 403

@app.route("/tobeornottobe", methods = ["GET", "POST"])
def ishe():
	"""
	Appelée quand un client rajoute un contact
	:return: 1 si l'utilisateur demandé existe 0 sinon
	"""

	if request.method == "POST":
		user = request.get_json()["id"].zfill(8)
		resp = {"exists":1}
		if codes.get(user) == None : 
			resp["exists"] = 0
		return resp

@app.route("/quit", methods=["GET", "POST"])
def quit():
	"""
	Appelée quand le client quitte sa session
	Libère son id
	:return: sans importance
	"""
	if request.method == "POST":
		rqData = request.get_json()
		if verif(rqData["userid"], rqData["usercode"]):
			codes.pop(rqData["userid"])
			newmessages.pop(rqData["userid"])
			print(codes)
		return {}

if __name__=="__main__":
	app.run(host="192.168.1.7", debug=True)



