


//MATH ALGO BBP

function pi_ser(j, n, prec){
    /*
    Calcule la somme des 16^(n-k)/(8k + j) pour k allant de 0 à D
    où D est une valeur de sécurité assure une certaine précision des décimales jusqu'au rang n + prec

    On travaille avec des bigint puisqu'on se retrouve avec des nombres d'au moins prec chiffres hex, soit 4prec chiffres binaires.
    La limite des entiers normalement utilisés en javascript est 2^53 - 1, (attribut publique MAX_SAFE_INTEGER de la classe Number)
     */

    let D = BigInt(pi_dn(n, prec));
    let D4 = 4n*D;//Pour faire des "bitshifts" de base 16;
    n = BigInt(n);

    let d = BigInt(j); //denominateur
    let s = 0n; // somme

    // Comme on s'intéresse uniquement aux décimales à partir du rang n, on peut calculer sous modulo les premiers membres de la somme
    for (var k = 0n; k < n+1n ; k++){
        s += (((16n**(n-k))%d)<<D4)/d; //
        d += 8n;
    }

    let t = 0n;
    let e = D4 - 4n;
    d = 8n*k + BigInt(j);

    //On continue de sommer jusqu'à ce que les membres de la somme soit
    while(true){
        let dt = (1n<<e)/d;
        if (!dt){
            break;
        }
        t += dt;
        e -= 4n;
        d += 8n;
    }
    return (s + t) ;
}

function pi_hex(n, prec){
    /*
    calcul avec BBP : on obtient un bandeau de pi de longueur prec débutant à la position n, en hexadécimal
     */
	n=Math.abs(Math.floor(n));
	prec=Math.abs(Math.floor(prec));
	n-=1;
	let a=[4n,2n,1n,1n]; //coef de séries dans BBP
	let j=[1n,4n,5n,6n];
	let D = BigInt(pi_dn(n, prec));
	//n = BigInt(n);
	let x = (a[0]*pi_ser(j[0], n, prec)
        - a[1]*pi_ser(j[1], n, prec)
        - a[2]*pi_ser(j[2], n, prec)
        - a[3]*pi_ser(j[3], n, prec)
        ) & (16n**D - 1n);

    prec = BigInt(prec);
	x = x / 16n**(D - prec);
	x = x.toString(16);
	return x;
}


function pi_dn(n,prec){
    /*
    Calcul de D qui va assurer la précision des décimales du calcul de pi jusqu'au rang n+prec+1
     */
	return Math.floor(Number(Math.log(n + prec + 1)/Math.log(16) + prec + 3));
}

//TRANSCRYPT

 function xor_two_str(a,b){
     /*
     Applique l'opérateur ou exclusif entre deux châines de caractères
     */
     let xored = "";
     for (let i = 0; i < a.length;i++){
         let u = (a.charCodeAt(i)^b.charCodeAt(i%b.length)).toString(16); //xor puis conversion en hex
         if (u.length < 2){ u = "0"+u }
         xored += u;
     }
     return xored;
 }


function crypt(clef, msg){
    /*
    Applique transcrypt à msg avec une clef donnée
     */
    return xor_two_str(msg,pi_hex(clef, msg.length)); // renvoie le message chiffré
 }


function hex_to_ascii(str1) {
    /*
    Convertit une chaîne de caractères hexadécimale en caractères ascii
     */
	let hex  = str1.toString();
	let str = '';
	for (let n = 0; n < hex.length; n += 2) {
		str += String.fromCharCode(parseInt(hex.substr(n, 2), 16));
	}
	return str;
 }


function decrypt(clef, msg){
    /*
    Inverse de crypt.
    On ne peut réutiliser crypt du fait de l'implémentation du xor en javascript.
     */
    return hex_to_ascii(xor_two_str(hex_to_ascii(msg), pi_hex(clef, msg.length)));
 }

//VARIABLES GLOBALES

var userid;
var usercode;
var keys = {};



function initialisation () {
	/*Fonction appelée lors du chargement de la page.
	Elle adapte le css aux dimensions de la page, et fait une requête au serveur
	  		pour obtenir un identifiant et un code 'secret', afin que le serveur puisse
	  		vérifier, lors des échanges futurs, que l'identité du client n'est pas usurpée.
	Aucun paramètre n'est utilisé. */


	//alert("Initialisation en cours");
	document.getElementById("contenuContact").style.maxHeight = window.innerHeight - 100 + "px";
	document.getElementById("contenuMessage").style.maxHeight = window.innerHeight - 257 + "px";
	document.getElementById("contenuMessage").style.minHeight = window.innerHeight - 257 + "px";
	

	$.ajax({
	type: "POST",
  	url: "/getid",
  	contentType: "application/json",
  	dataType: 'json',
  	success: function(result) { //un dictionnaire de la forme {"userid": , "usercode": }
  			userid = result["userid"];
  			usercode = result["usercode"];
  			document.getElementById("nameUser").innerHTML = "User_"+userid;
  		} 
	});
}




// FONCTIONS CLIENT SEUL



function nouvelleTaille () {
	/*Fonction appelée dès que la fenêtre change de taille ou que le client
			saisi un nouveau caractère lors de la composition de son message.
	Elle adapte la taille de la conversation et de la liste des contacts,
			à la taille de la fenêtre et du message en cours de rédaction.
			Elle assure aussi la transition entre les différents modes d'affichage
			(écran large et écran mince)
	Aucun paramètre n'est utilisé. */


	document.getElementById("contenuContact").style.maxHeight = window.innerHeight - 100 + "px";
	let tailleInput = document.getElementById("messageAEnvoyer").scrollHeight;
	let tailleSpan = document.getElementById("envoyerMessage").style.height;

	if (tailleInput>200){
		document.getElementById("contenuMessage").style.maxHeight = window.innerHeight - parseInt(tailleSpan.slice(0, -1)) -177 + "px";
		document.getElementById("contenuMessage").style.minHeight = window.innerHeight - parseInt(tailleSpan.slice(0, -1)) -177 + "px";
	}
	else {
		document.getElementById("contenuMessage").style.maxHeight = window.innerHeight - tailleInput - 208 + "px";
		document.getElementById("contenuMessage").style.minHeight = window.innerHeight - tailleInput - 208 + "px";
	}

	if (window.innerWidth > 630){
		document.getElementById("main").style.display = "initial";
		document.getElementById("contenuContact").style.display = "initial";
	}
	else if (document.getElementById("main").style.display != "none"
		&& document.getElementById("contenuContact").style.display != "none"){
		document.getElementById("main").style.display = "initial";
		document.getElementById("contenuContact").style.display = "none";

	}
}



function changeArea(){
	/*Fonction appelée lorsque le bouton d'id "boutonRetour" est cliqué.
	Elle permet de retourner à la liste des contacts, lorsque la 
			messagerie est utilisée sur un écran ou une fenêtre mince.
	Aucun paramètre n'est utilisé. */


	document.getElementById("main").style.display = "none";
	document.getElementById("contenuContact").style.display = "initial";t
}



function afficherConversationContact (e) {
	/*
	 Fonction appelée lorsque l'on clique sur le bouton associé à un contact, lorsque le client ouvre une nouvelle
	 conversation avec un autre utilisateur et lorsque le client reçoit un message.Elle permet de modifier le css d'un
	 bouton associé à un contact, lorsqu'il est cliqué, d'afficher la conversation avec ce contact, et de définir ce
	 contact comme cible du prochain message (première ligne de la fonction).
	 Le paramètre "e" est l'id du bouton associé au contact d'identifiant e.slice(0, -4)
	 */


	//alert("aConvContact en cours")
	document.getElementById("messageAEnvoyer").dataCible = e.slice(0, -4);

	let listeContacts = document.querySelectorAll(".caseContact");
	listeContacts.forEach(function(userId) {
			document.getElementById(userId.getAttribute("id")).style.backgroundColor = "#1F1F1F";
	});
	document.getElementById(e).style.backgroundColor = "#540000";

	let listeDiscussions = document.querySelectorAll(".convContainers");
	listeDiscussions.forEach(function(userId) {
			document.getElementById(userId.getAttribute("id")).style.display = "none";
	});
	document.getElementById(e.slice(0, -4)).style.display = "initial";

	document.getElementById("barreContact").innerHTML = "User_"+e.slice(0, -4);

	document.getElementById("contenuMessage").scrollTo(0, document.getElementById("contenuMessage").scrollHeight);

	if (window.innerWidth <= 630){
		document.getElementById("contenuContact").style.display = "none";
		document.getElementById("main").style.display = "initial";
	}
}



function afficherContact (nom, lastMessage){
	/*Fonction appelée lorsque le client ouvre une nouvelle 
			conversation avec un autre utilisateur, et lorsque le 
			client reçoit un message d'un utilisateur avec qui il 
			n'a jamais conversé.
	Elle permet de créer dans la liste des contacts, un nouveau bouton
			cliquable associé à l'utilisateur "nom".
	Le paramètre "nom" est l'identifiant du contact que représente le bouton et 
			"lastMessage" est le dernier message échangé avec ce contact. */


    //alert("afficherContact en cours");
    let boxContact = document.createElement("div");
    let nameContact = document.createElement("h1");
    let latestWord = document.createElement("p");

    boxContact.setAttribute("id", nom + "case");
    boxContact.setAttribute("onclick", "afficherConversationContact(this.id)");
    boxContact.setAttribute("class", "caseContact");
    nameContact.setAttribute("class", "nomContact");
    latestWord.setAttribute("class", "derniersMots");
    latestWord.setAttribute("id", "derniersMots"+nom);

    nameContact.appendChild(document.createTextNode("User_"+nom));
    latestWord.appendChild(document.createTextNode(lastMessage));

    boxContact.appendChild(nameContact);
    boxContact.appendChild(latestWord);

    document.getElementById("contenuContact").appendChild(boxContact);

    document.getElementById("messageAEnvoyer").dataCible = nom;
}



function newConv (id) {
	/*Fonction appelée lorsque le client ouvre une nouvelle 
			conversation avec un autre utilisateur, et lorsque le 
			client reçoit un message d'un utilisateur avec qui il 
			n'a jamais conversé.
	Elle permet de créer un espace de discussion avec le nouveau 
			contact, et avec le message introducteur (qui rappelle que 
			l’échange est crypté). Elle appelle aussi les fonctions
			afficherContact et afficherConversationContact.
	Le paramètre "nom" est l'identifiant du nouveau contact. */

	//alert("newConv en cours");
	document.getElementById("idNouveauContact").value = "";
	let messageIntro = document.createElement("div");
	messageIntro.setAttribute("class", "messageIntro");
	messageIntro.appendChild(document.createTextNode("Cette conversation est sécurisée"));
	let convContainer = document.createElement("div");
	convContainer.setAttribute("id", id);
	convContainer.setAttribute("class", "convContainers");
	convContainer.appendChild(messageIntro);
	document.getElementById("contenuMessage").appendChild(convContainer);
	afficherContact(id, "");
	let sentIdUser = id+"case";
	afficherConversationContact(sentIdUser);
}



function afficherMessage (me, others, valeur){
	/*Fonction appelée lorsque le client reçoit ou envoie un message.
	Elle permet d’afficher les messages envoyés et reçus et d’adapter le 
			bouton associé à l’utilisateur avec lequel se passe l’échange. 
			Lorsque le client reçoit le premier message d’un autre utilisateur, 
			la fonction appelle la fonction newConv.
	Le paramètre "me" prend la valeur 1 lorsque l’auteur du message est le 
			client. Le paramètre "others" est l’identifiant de l’utilisateur 
			avec lequel le client interagit. Le paramètre "valeur" est le contenu 
			du message. */ 


	//alert("aMessage en cours");
	let booleen = false;
	let listeDiscussions = document.querySelectorAll(".caseContact");
	listeDiscussions.forEach(function(userId) {
		let idDiscussion = userId.getAttribute("id");
  		if (idDiscussion.slice(0, -4) == others) {
  			booleen = true;
  		}
	});

	if (booleen == false) {
		newConv(others);
	}

    let myMessage = document.createElement("p");
    let myContainer = document.createElement("article");

	if (me==1){
		myMessage.setAttribute("class", "fromUser");
      	myContainer.setAttribute("class", "rightContainer");
	}
	else {
		myMessage.setAttribute("class", "toUser");
      	myContainer.setAttribute("class", "leftContainer");
	}

    myMessage.appendChild(document.createTextNode(valeur));

    myContainer.appendChild(myMessage);

    document.getElementById(others.toString()).appendChild(myContainer);

    document.getElementById("derniersMots"+others).innerHTML = valeur;

    afficherConversationContact(others+"case");

    document.getElementById("contenuMessage").scrollTo(0, document.getElementById("contenuMessage").scrollHeight);
}



function sendInJs(cible) {
	/*Fonction appelée si l’envoie du message au serveur se déroule bien. 
	Elle permet de vider la barre de saisie du message qui a été envoyé, 
			et d’afficher ce message grâce à la fonction afficherMessage.
	Le paramètre "cible" est l’identifiant du destinataire du message. */ 


	//alert("sdInJs en cours ");
	afficherMessage(1, parseInt(cible),  document.getElementById("messageAEnvoyer").value);

	document.getElementById("messageAEnvoyer").value="";
	nouvelleTaille();
}




//FONCTIONS CLIENT-SERVEUR



function sendToServeur(){
	/*Fonction appelée lorsque le client presse la touche Entrer ou appuie
			 sur le bouton d’envoi du message. 
	Elle permet d’envoyer le message et son destinataire au serveur, et 
			d’appeler sendInJs si l’opération est effectuée avec succès
	Aucun paramètre n'est utilisé. */


	//alert("sendToServeur en cours")
	let cible = document.getElementById("messageAEnvoyer").dataCible;
	let key = keys[cible];
	let clair = document.getElementById("messageAEnvoyer").value;
	let message = crypt(Math.floor(key/10000), crypt(key%10000, clair));

	//getMessage();   //on a besoin de le mettre ca ?

	$.ajax(	{
	type: "POST",
  	url: "/send",
	data: JSON.stringify({"userid":userid , "usercode":usercode , "to":cible , "msg":"", "key":"false"}),
  	contentType: "application/json",
  	dataType: 'json',
  	success: function (){
		sendInJs(cible);
	},
	error: function (xhr, status, error){
		if (xhr.status == 403){
			window.location.href = "/expire"
		}
		if (xhr.status == 400){
			alert("Erreur 400 : L'utilisateur demandé n'existe pas");
		}
	}
});
}



function doesUserBe(id){
	/*Fonction appelée quand le client saisit un caractère dans le 
			champ dédié à la recherche de nouveaux contacts, et que 
			le client dont l’identifiant a été saisi, n’est pas dans 
			les contacts du client.
	Elle permet de faire une requête au serveur afin de savoir si 
			l’identifiant renseigné est associé a un client connecté au serveur.
	Le paramètre "id" est l’identifiant à rechercher. */



	//alert("doesUserbe en cours");
	$.ajax({
		type:"POST",
		url : "/tobeornottobe",
		data : JSON.stringify({"id":id.toString()}),
		contentType : 'application/json',
		dataType : 'json', //le serveur renvoie un objet de la forme {"exists":} exists = O ou 1
		success : function(result){
			if (result["exists"] == 1){
				newConv(id);
			} else {
				alert("L'utilisateur " +  id.toString() + " n'existe pas");
			}
		}
	});
}



function chercherNouveauContact(e) {
	/*Fonction appelée quand le client saisit un caractère dans le champ 
			dédié à la recherche de nouveaux contacts.
	Elle permet de regarder si l’utilisateur que le client recherche 
			est déjà dans sa liste de contact. S’il ne l’est pas, la 
			fonction doesUserBe est appelée lorsque le client presse 
			la touche Entrer.
	Le paramètre "e" est la touche que le client presse dans le champ 
			dédié à la recherche de nouveaux contacts. */


	//alert("chercher contact en cours")
	let sentId = document.getElementById("idNouveauContact").value;
	let bool = false;

    	let listeDiscussions = document.querySelectorAll(".convContainers");

		listeDiscussions.forEach(function(userId) {
  			if (userId.getAttribute("id") == sentId) {
  				bool = true;
  			}
		});
	if(e.keyCode==13 && bool==false && sentId!=""){
		doesUserBe(parseInt(sentId));
	}
}



function getMessage(){
	/*Fonction appelée toute les secondes (cet intervalle pourrait être
			 bien plus court mais en vue d’un déploiement à grande échelle, 
			 nous avons essayé de réduire le nombre de requetés au serveur).
	Elle permet de faire une requête au serveur afin de vérifier si un message
			a été envoyé au client. Si le message est une clef de communication,
			celle-ci est stockée du coté du client (et supprimée sur le serveur), 
			sinon la fonction afficherMessage est appelée.
	Aucun paramètre n'est utilisé. */

	$.ajax({
		type: "POST",
  		url: "/check",
		data:JSON.stringify({"userid": userid , "usercode": usercode} ), //de la forme {"userid": , "usercode";}
  		contentType: "application/json",
  		dataType: 'json',    // une liste d'objets de la forme {"id": , "msg":}
  		success: function(result) {
  			for (let i = 0 ; i < result.length ; i++){
  				if (result[i]["key"]=="true"){
  					keys[result[i]["id"]] = result[i]["msg"];
  				}
  				else {
					  let cible = result[i]["id"]
					  let key = keys[cible];
					  let cryp = result[i]["msg"];
					  let message = decrypt(key%10000, decrypt(Math.floor(key/10000), cryp));
					  afficherMessage(0,parseInt(cible),message);

  				}
  			}
  		},
		error: function () {
			window.location.href = "/expire";
		}
	});
}

//
//on peut essayer de faire une seule fonction avec sendKey et sendToServeur
/*
function sendToServeur(firstmes){ //vraie si clef, faux sinon
	if (firstmes) {
		let message = Math.floor(Math.random() * 1000000000);
		let iskey = "true"; //c'est normal que ce soit une string
	} else {
		let message = document.getElementById("messageAEnvoyer").value;
		let iskey = "false";
	}
	let cible = document.getElementById("messageAEnvoyer").dataCible;
	getMessage();
	$.ajax(	{
	type: "POST",
  	url: "/send",
	data: JSON.stringify({"userid":userid , "usercode":usercode , "to":cible , "msg":message, "key":iskey}),
  	contentType: "application/json",
  	dataType: 'json',
  	success: sendInJs(cible) //le serveur ne répond rien, mais cette partie pourrait être utilisée pour faire apparaître le message avec un objet de la classe dédiée
});
}

//On devrait cependant aussi modifier la fn maybeSend
 */


function sendKey(){
	/*Fonction appelée juste avant l’envoie du premier message d’une conversation.
	Elle permet de générer et d’envoyer la clef de communication à l’autre utilisateur.
	Aucun paramètre n'est utilisé. */

 	let key = Math.floor(Math.random() * 100000000); //10^8
  	let cible = document.getElementById("messageAEnvoyer").dataCible;
  	$.ajax( {
  		type: "POST",
	  	url: "/send",
	  	data: JSON.stringify({"userid":userid , "usercode":usercode , "to":cible , "msg":key, "key":"true"}),
	  	contentType: "application/json",
	  	dataType: 'json',
		async: false,
	  	success: function (){
	  		keys[cible] = key;
		},
		error: function (xhr, status, error){
			  if (xhr.status == 403){
				  window.location.href = "/expire"
			  }
			  if (xhr.status == 400){
				  alert("Erreur 400 : L'utilisateur demandé n'existe pas");
			  }
		}
	});
}

function maybeSend(e) {
	/*
	Fonction appelée dès que le client saisi un nouveau caractère dans la barre dédiée à la composition du message.
	Elle permet d’échanger avec l’autre utilisateur une clef grâce à la fonction sendKey et d’envoyer le message si
	la touche saisie est "Entrer". Cette fonction permet aussi d’adapter la mise en page de la page en fonction de la
	taille du message, grâce à la fonction nouvelleTaille.
	Le paramètre "e" est la touche que le client presse dans le champ dédié à la recherche de nouveaux contacts.
	 */

	let message = document.getElementById("messageAEnvoyer").value;
	if(e.keyCode==13 && message != ""){
		let idCible = document.getElementById("messageAEnvoyer").dataCible;
		let contenuDeMessage = document.getElementById(idCible);
		let enfantContenuDeMessage = contenuDeMessage.children;
		if (enfantContenuDeMessage.length == 1){
				sendKey();
		}
		sendToServeur();
	}
	let taille = document.getElementById("messageAEnvoyer").scrollHeight;
	if(taille < 200){
		document.getElementById("envoyerMessage").style.height = taille + 30 + "px";
		nouvelleTaille();
	}
}

function quit(){
	/*
	Fonction appelée quand l'utilisateur quitte la page, pour que le serveur marque l'id comme non utilisée
	 */
	$.ajax( {
		type: "POST",
	  	url: "/quit",
	  	data: JSON.stringify({"userid":userid , "usercode":usercode}),
	  	contentType: "application/json",
	  	dataType: 'json',
	});
}

setInterval(getMessage, 2000);