#import cython

class Groupe :

    def __init__(self, maxmembers) :
        self.maxmembers = maxmembers
        self.current = 0 #on utilise .current pour le nombre d'utilisateurs total, len(self) pour le nombre d'utilisateur publics
        self.members = {} #à remplacer par un tableau en cython #(code, pseudo, public)
        self.pseudoR = [("", "")]  #liste ordonnée d'élément {pseudo : id}

    def __len__(self): #nombre d'utilisateur publics, utiliser self.current pour le nombre n'utilisateurs total
        return len(self.pseudoR)

    def __getitem__(self, item):
        if isinstance(item, str) :
            return self.members[item]
        if isinstance(item, int) :
            return self.pseudoR[item]
        else : return KeyError(f"__getitem__ error : item must be str or int, was provided {type(item)}")

    def __str__(self):
        pmember = [" ; ".join(map(str, self.members[key])) for key in self.members]
        return "\n".join(pmember)

    def stillexist(self, ident):
        return self.members.get(ident) is not None

    def addmember(self, identifiant, code, pseudo, public=True):
        if self.current == self.maxmembers :
            raise IndexError(f"Tentative d'ajout de membre au groupe au delà du max prévu")

        self.members[identifiant] = (code, pseudo, public) #utiliser une struc en cython

        if public :
            ilow = self.findi(pseudo)

            if (ilow < self.current) and (self.pseudoR[ilow] == pseudo) :
                return 1
            self.pseudoR.insert(ilow, (pseudo, identifiant))

        self.current += 1
        return 0

    def delmember(self, identifiant):
        pseudo, public = self[identifiant][1], self[identifiant][2]

        self.members.pop(identifiant)

        if public:
            ilow = self.findi(pseudo)
            self.pseudoR.pop(ilow)

        self.current -= 1

    def cpseudo(self, ident, npseudo):
        code, _, public = self.members[ident]

        self.delmember(ident)
        self.addmember(ident, code, npseudo, public)


    def setpublic(self, ident):
        code, pseudo, public = self.members[ident]
        if public :
            return 1
        self.delmember(ident)
        self.addmember(ident, code, pseudo, True)

    def setprive(self, ident):
        code, pseudo, public = self.members[ident]
        if not public :
            return 1
        self.delmember(ident)
        self.addmember(ident, code, pseudo, False)

    def verif(self, ident, code):
        try:
            return (self[ident][0] == code)
        except KeyError:
            return False

    def findi(self,  tofind):
        """
        :param tofind: element à trier
        :return: le plus petit indice d'un objet geq à tofind, peut être sup à self.maxmembers
        """

        x1 = 0
        x2 = len(self.pseudoR)-1
        if self.pseudoR[x2][0] < tofind:
            return x2+1

        xm = (x1 + x2)//2
        while x1 < x2 :
            if self[xm][0] < tofind :
                x1 = xm + 1
            else : x2 = xm
            xm = (x1 + x2)//2

        return xm
        
    
    def match(self, tomatch):

        if tomatch == "":
            if len(self.pseudoR) == 1 : #càd quand il n'y que l'élément minimal factice
                return 1, 1, False
            return 1, len(self.pseudoR) - 1, True

        i1 = self.findi(tomatch)
        i2 = self.findi(tomatch[:-1]+chr(ord(tomatch[-1]) + 1))

        if (i1 == i2) :
            try :
                if not (self.pseudoR[i1][0][:len(tomatch)] == tomatch) and (self.members[self.pseudoR[i1][1]][2] == True):
                    return i1, i2, False
            except IndexError :
                print(f" erreur Groupe.match(), delta : {i1 - len(self.pseudoR)}")
        return  i1, i2, True
